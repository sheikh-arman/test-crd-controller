// +k8s:deepcopy-gen=package
// +k8s:defaulter-gen=TypeMeta
// +groupName=arman.com

package v1alpha1
